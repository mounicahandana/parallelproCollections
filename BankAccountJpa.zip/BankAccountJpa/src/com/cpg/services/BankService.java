package com.cpg.services;


import com.cpg.dao.BankDao;
import com.cpg.entity.Bank;
import com.cpg.entity.Transaction;

public class BankService implements IBankService
{
	BankDao dao=new BankDao();

	@Override
	public Bank getAccountById(int id) {
		Bank bank  = dao.getAccountById(id) ;
		return bank;
	}

	@Override
	public void createAccount(Bank bank) {
		dao.beginTransaction();
		dao.createAccount(bank);
		dao.commitTransaction();
		
	}

	@Override
	public void showBalance(Bank bank) {
		
		
	}

	@Override
	public void Deposit(Bank bank) {
		dao.beginTransaction();
		dao.Deposit(bank);	
		dao.commitTransaction();
		
	}

	@Override
	public void Withdraw(Bank bank) {
		dao.beginTransaction();
		dao.Withdraw(bank);
		dao.commitTransaction();
		
	}

	@Override
	public void printTransactions(int id) {
		 dao.PrintTransactions(id);
		
	}

	@Override
	public void commitTransaction() {
		dao.commitTransaction();
		
	}

	@Override
	public void beginTransaction() {
		dao.beginTransaction();
		
	}

	public void addTransaction(Transaction trans) {

	dao.beginTransaction();
	dao.addTransaction(trans);
	dao.commitTransaction();
	}

}