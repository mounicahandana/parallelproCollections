package com.cpg.services;

import com.cpg.entity.Bank;

public interface IBankService {
	public   Bank getAccountById(int id);

	public   void createAccount(Bank bank);

	public   void showBalance(Bank bank);

	public  void Deposit(Bank bank);
	
	public void Withdraw(Bank bank);
	
	public void printTransactions(int id);

	public  void commitTransaction();

	public void beginTransaction();
}
