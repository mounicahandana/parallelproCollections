package com.cpg.entity;

import java.util.Random;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "BankDetails")
public class Bank {
	@Id
	private int accountId;
	@Column(length = 20)
	private String accountantName;
	@Column(length = 10)
	private String mobileNo;
	// private String address;
	@Column(length = 10)
	private int accBalance;

	@OneToOne
	public int ran(int min, int max) {
		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId() {
		this.accountId = ran(1000,9999);
	}

	public String getAccountantName() {
		return accountantName;
	}

	public void setAccountantName(String accountantName) {
		this.accountantName = accountantName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(int accBalance) {
		this.accBalance = accBalance;
	}
	public void setTrans(Transaction trans) {
		// TODO Auto-generated method stub
		
	}
}
