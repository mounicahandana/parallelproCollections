package com.cpg.dao;

import com.cpg.entity.Bank;

public interface IBankDao {
	public   Bank getAccountById(int id);

	public   void createAccount(Bank bank);

	public   void showBalance(Bank bank);

	public  void Deposit(Bank bank);
	
	public void Withdraw(Bank bank);
	
	public void PrintTransactions(int id);

	public  void commitTransaction();

	public void beginTransaction();
}
