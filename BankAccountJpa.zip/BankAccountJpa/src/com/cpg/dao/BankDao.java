package com.cpg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import com.cpg.entity.Bank;
import com.cpg.entity.Transaction;

public class BankDao implements IBankDao {
	EntityManager entity = Util.getEntityManager();

	@Override
	public Bank getAccountById(int id) {
		Bank bank = entity.find(Bank.class, id);
		return bank;
	}

	@Override
	public void createAccount(Bank bank) {
		entity.persist(bank);
	}

	@Override
	public void showBalance(Bank bank) {
		// TODO Auto-generated method stub

	}

	@Override
	public void Deposit(Bank bank) {
		entity.merge(bank);

	}

	@Override
	public void Withdraw(Bank bank) {
		entity.merge(bank);
	}

	@Override
	public void PrintTransactions(int id) {
		Query q = entity.createQuery("select t from TransactionDetails t where accId=:tid");
		q.setParameter("tid", id);
		List<Transaction> l = q.getResultList();
		System.out.println("TransactionId		Account Id		TransactionType		Amount");
		System.out.println("------------------------------------------------------------------");
		for (Transaction tdetails : l) {
			System.out.println(tdetails.getTransactionId() + "			 " + tdetails.getAccountId() + "			"
					+ tdetails.getTransactionType() + "		           " + tdetails.getAmount());
		}

	}

	@Override
	public void commitTransaction() {
		entity.getTransaction().commit();

	}

	@Override
	public void beginTransaction() {
		entity.getTransaction().begin();

	}

	public void addTransaction(Transaction trans) {
		entity.persist(trans);

	}

}
