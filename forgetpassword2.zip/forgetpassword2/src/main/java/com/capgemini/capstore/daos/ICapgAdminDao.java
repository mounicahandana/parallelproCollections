package com.capgemini.capstore.daos;

import java.util.List;

import com.capgemini.capstore.bean.CapgAdmin;

public interface ICapgAdminDao {

	public CapgAdmin addAdminDao(CapgAdmin admin);
	
	public List<CapgAdmin> getAllAdminDao();
	
	public CapgAdmin getAdminDao(int adminId);
	
	public CapgAdmin getAdminByEmailDao(String emailId);


	
	
}
