package com.capgemini.capstore.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.bean.CapgAdmin;
import com.capgemini.capstore.bean.CapgCustomer;


@Repository
public interface CustomerDao extends JpaRepository<CapgCustomer, Integer> {

	
	@Query("from capgcustomer where CUSTOMER_EMAIL  = :emailId")
	public CapgCustomer getCustomer(@Param("emailId") String emailId);
	
	
	/*@Query("select u.password from User u where u.emailid=?1")
	public String getUserPassword(String emailId);*/

}