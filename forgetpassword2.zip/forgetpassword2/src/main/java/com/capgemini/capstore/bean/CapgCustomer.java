package com.capgemini.capstore.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;
@Component
@Entity(name="capgcustomer")
public class CapgCustomer {
	
	@Id
	@SequenceGenerator(name="seq" , sequenceName = "admin_seq")
    @GeneratedValue(generator = "seq")
	private int customerId;
	private String customerName;
	private String customerMobile;
	private String customerEmail;
	private double customerWallet;
	private String customerPassword;
	private String customerHistory;
	private int cartID;
	private String customerEncryptedPassword;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerMobile() {
		return customerMobile;
	}
	public void setCustomerMobile(String customerMobile) {
		this.customerMobile = customerMobile;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public double getCustomerWallet() {
		return customerWallet;
	}
	public void setCustomerWallet(double customerWallet) {
		this.customerWallet = customerWallet;
	}
	public String getCustomerPassword() {
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}
	public String getCustomerHistory() {
		return customerHistory;
	}
	public void setCustomerHistory(String customerHistory) {
		this.customerHistory = customerHistory;
	}
	public int getCartID() {
		return cartID;
	}
	public void setCartID(int cartID) {
		this.cartID = cartID;
	}
	public String getCustomerEncryptedPassword() {
		return customerEncryptedPassword;
	}
	public void setCustomerEncryptedPassword(String customerEncryptedPassword) {
		this.customerEncryptedPassword = customerEncryptedPassword;
	}
	
	
	
	
	


	

}
