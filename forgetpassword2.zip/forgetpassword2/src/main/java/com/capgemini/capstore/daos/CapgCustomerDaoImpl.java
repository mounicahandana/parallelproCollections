package com.capgemini.capstore.daos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.bean.CapgCustomer;
@Repository
public class CapgCustomerDaoImpl implements ICapgCustomerDao{

	@Autowired
	CustomerDao customerRepo;
	
	@Override
	public CapgCustomer addCustomerDao(CapgCustomer customer) {
		// TODO Auto-generated method stub
		return customerRepo.save(customer);
		
	}

	@Override
	public List<CapgCustomer> getAllCustomerDao() {
		return customerRepo.findAll();
	}

	@Override
	public CapgCustomer getCustomerDao(int customerId) {
		// TODO Auto-generated method stub
		return customerRepo.findById(customerId).orElse(null);
	}

	@Override
	public CapgCustomer getCustomerByEmailDao(String emailId) {
		// TODO Auto-generated method stub
		return customerRepo.getCustomer(emailId);
	}

}
