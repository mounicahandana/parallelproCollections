package com.capgemini.capstore.daos;

import java.util.List;

import com.capgemini.capstore.bean.CapgCustomer;

public interface ICapgCustomerDao {
	
	
	public CapgCustomer addCustomerDao(CapgCustomer customer);
	
	public List<CapgCustomer> getAllCustomerDao();
	
	public CapgCustomer getCustomerDao(int customerId);
	
	public CapgCustomer getCustomerByEmailDao(String emailId);

	
	


}
