package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.bean.CapgAdmin;
import com.capgemini.capstore.bean.CapgCustomer;
import com.capgemini.capstore.bean.CapgMerchant;

public interface PasswordService {

	//public String getPassword(String email, String category,String ans1,String ans2);
	public CapgAdmin addAdminService(CapgAdmin admin);
	
	public CapgCustomer addCustomerService(CapgCustomer customer);
	
	public CapgMerchant addMerchantService(CapgMerchant merchant);
	
	public List<CapgAdmin> getAllAdminService();
	
	public CapgAdmin getAdminService(int adminId);
	
	public void addCustomerDao(CapgCustomer customer);
	
	public List<CapgCustomer> getAllCustomerDao();
	
	public CapgCustomer getCustomerDao(int customerId);
	
	public void addMerchantDao(CapgMerchant merchant);
	
	public List<CapgMerchant> getAllMerchantDao();
	
	public CapgMerchant getMerchantDao(int merchantId);

	public String getPasswordService(String emailId, String type);
	
	
	
}