package com.capgemini.capstore.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.bean.CapgAdmin;

@Repository
public interface AdminDao extends JpaRepository<CapgAdmin,Integer> {
	
	@Query("from capgadmin admin where admin.emailid = :emailId")
	public CapgAdmin getAdmin(@Param("emailId") String emailId);
	//query.setMaxResults(1).uniqueResult();

}
