package com.capgemini.capstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.bean.CapgAdmin;
import com.capgemini.capstore.bean.CapgCustomer;
import com.capgemini.capstore.bean.CapgMerchant;
import com.capgemini.capstore.daos.AdminDao;
import com.capgemini.capstore.daos.CapgAdminDaoImpl;
import com.capgemini.capstore.daos.CapgCustomerDaoImpl;
import com.capgemini.capstore.daos.CapgMerchantDaoImpl;
import com.capgemini.capstore.daos.MerchantDao;
import com.capgemini.capstore.daos.CustomerDao;


@Service
public class PasswordServiceImp implements PasswordService{

	@Autowired
	CapgAdminDaoImpl adminDao;
	
	@Autowired
	CapgMerchantDaoImpl merchantDao;
	
	@Autowired
	CapgCustomerDaoImpl customerDao;
	
	
	@Override
	public CapgAdmin addAdminService(CapgAdmin admin) {
		// TODO Auto-generated method stub
		return adminDao.addAdminDao(admin);
		
	}

	@Override
	public CapgCustomer addCustomerService(CapgCustomer customer) {
		// TODO Auto-generated method stub
		return customerDao.addCustomerDao(customer);
	}

	@Override
	public CapgMerchant addMerchantService(CapgMerchant merchant) {
		// TODO Auto-generated method stub
		return merchantDao.addMerchantDao(merchant);
	}
	

	
	
	
	
	@Override
	public List<CapgAdmin> getAllAdminService() {
		// TODO Auto-generated method stub
		return adminDao.getAllAdminDao();
	}

	@Override
	public CapgAdmin getAdminService(int adminId) {
		// TODO Auto-generated method stub
		return adminDao.getAdminDao(adminId);
	}

	@Override
	public void addCustomerDao(CapgCustomer customer) {
		// TODO Auto-generated method stub
		customerDao.addCustomerDao(customer);
		
	}

	@Override
	public List<CapgCustomer> getAllCustomerDao() {
		// TODO Auto-generated method stub
		return customerDao.getAllCustomerDao();
	}

	@Override
	public CapgCustomer getCustomerDao(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.getCustomerDao(customerId);
	}

	@Override
	public void addMerchantDao(CapgMerchant merchant) {
		// TODO Auto-generated method stub
		merchantDao.addMerchantDao(merchant);
		
	}

	@Override
	public List<CapgMerchant> getAllMerchantDao() {
		// TODO Auto-generated method stub
		return merchantDao.getAllMerchantDao();
	}

	@Override
	public CapgMerchant getMerchantDao(int merchantId) {
		// TODO Auto-generated method stub
		return merchantDao.getMerchantDao(merchantId);
	}

	@Override
	public String getPasswordService(String emailId, String type) {
		
		String password;
		// TODO Auto-generated method stub
		if(type.equalsIgnoreCase("customer")) {
			CapgCustomer customer = customerDao.getCustomerByEmailDao(emailId);
			 password = customer.getCustomerPassword();
		}
		else if(type.equalsIgnoreCase("merchant")) {
			CapgMerchant merchant = merchantDao.getMerchantByEmailDao(emailId);
			password = merchant.getMerchantPassword();
		}
		else {
			CapgAdmin admin = adminDao.getAdminByEmailDao(emailId);
			password = admin.getPassword();
		}
		
		return password;
		
	}

	
}
