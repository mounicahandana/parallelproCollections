package com.capgemini.capstore.daos;

import java.util.List;

import com.capgemini.capstore.bean.CapgMerchant;

public interface ICapgMerchantDao {

	public CapgMerchant addMerchantDao(CapgMerchant merchant);
	
	public List<CapgMerchant> getAllMerchantDao();
	
	public CapgMerchant getMerchantDao(int merchantId);
	
	public CapgMerchant getMerchantByEmailDao(String emailId);

	
}
