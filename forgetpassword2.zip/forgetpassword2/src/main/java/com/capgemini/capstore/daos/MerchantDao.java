package com.capgemini.capstore.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.bean.CapgCustomer;
import com.capgemini.capstore.bean.CapgMerchant;

@Repository
public interface MerchantDao extends JpaRepository<CapgMerchant, Integer> {
	
	/*@Query("select m.password from Merchant m where m.emailid=?1")
	public String getMerchantPassword(String emailId);
*/
	
	@Query("from capgmerchant where MERCHANT_EMAIL = :emailId")
	public CapgMerchant getMerchant(@Param("emailId") String emailId);
}
