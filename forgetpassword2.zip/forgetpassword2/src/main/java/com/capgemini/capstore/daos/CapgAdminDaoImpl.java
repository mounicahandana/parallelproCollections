package com.capgemini.capstore.daos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.bean.CapgAdmin;
@Repository
public class CapgAdminDaoImpl implements ICapgAdminDao{
	
	@Autowired
	AdminDao adminRepo;

	@Override
	public CapgAdmin addAdminDao(CapgAdmin admin) {
		// TODO Auto-generated method stub
		return adminRepo.save(admin);
		
	}

	@Override
	public List<CapgAdmin> getAllAdminDao() {
		// TODO Auto-generated method stub
		return adminRepo.findAll();
	}

	@Override
	public CapgAdmin getAdminDao(int adminId) {
		// TODO Auto-generated method stub
		return adminRepo.findById(adminId).orElse(null);
	}

	@Override
	public CapgAdmin getAdminByEmailDao(String emailId) {
		// TODO Auto-generated method stub
		return adminRepo.getAdmin(emailId);
	}

}
