export class Password
{
    merchantPassword:String;
    customerPassword:String;
     password:String;
     
}