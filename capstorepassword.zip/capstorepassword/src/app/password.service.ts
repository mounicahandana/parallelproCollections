import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PasswordService {

  private baseUrl='http://localhost:5000/forgetPassword';

  constructor(private http:HttpClient) { }

  getPassword(emailId:String,type:String):Observable<any>
  {
    return this.http.get(this.baseUrl+"/"+emailId+"/"+type,{responseType:'text'});
  }
}
// return this.http.post(
//   'http://10.0.1.19/login',
//   {email, password},
//   {responseType: 'text'})