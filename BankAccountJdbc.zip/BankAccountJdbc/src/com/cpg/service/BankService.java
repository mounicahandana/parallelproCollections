package com.cpg.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cpg.bean.Customer;
import com.cpg.bean.Transaction;
import com.cpg.dao.BankDao;
import com.cpg.dao.IBankDao;
import com.cpg.exception.BankAccountException;

public class BankService implements IBankService {
	IBankDao bankdao = new BankDao();

	@Override
	public int createAccount(Customer customerData, double amount) throws BankAccountException {
		return bankdao.createBankAccount(customerData, amount);
	}

	@Override
	public boolean isAddressValid(String address) throws BankAccountException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{4,}";

		if (!Pattern.matches(nameRegEx, address)) {
			throw new BankAccountException("first letter should be capital and length should be greater than 3");

		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

	@Override
	public boolean isMobileValid(String mobile) {
		Pattern numberptn = Pattern.compile("^[7,8,9]{1}[0-9]{9}$");

		Matcher match = numberptn.matcher(mobile);
		if (match.matches()) {
			return true;
		}
		return false;

	}

	@Override
	public boolean isAmountValid(double amount) throws BankAccountException {
		boolean amountFlag = false;

		if (amount < 20) {
			throw new BankAccountException("Amount should not be less than 20");
		} else {
			amountFlag = true;

		}
		return amountFlag;

	}

	@Override
	public boolean isValid(String name) {
		int n = name.length();
		char[] ch = name.toCharArray();
		for (int i = 0; i < n; i++) {
			try {
				if (ch[i] > 64 && ch[i] < 122 && ch[0] > 64 && ch[0] < 90) {
					continue;
				} else {
					throw new Exception("Invalid Name");
				}
			} catch (Exception E) {
				System.out.println(E);
				return false;
			}

		}
		return true;
	}

	@Override
	public double showBalance(int accountNo) throws BankAccountException {
		return bankdao.showBalance(accountNo);
	}

	@Override
	public List<Transaction> deposit(int accountNo, double amount) throws BankAccountException {
		return bankdao.deposit(accountNo, amount);
	}

	@Override
	public List<Transaction> withdraw(int accountNo, double amount) throws BankAccountException {
		return bankdao.withdraw(accountNo, amount);
	}

	@Override
	public List<Transaction> fundTransfer(int sourceAccount, int destinationAccount, double amount)
			throws BankAccountException {
		return bankdao.fundTransfer(sourceAccount, destinationAccount, amount);
	}

	@Override
	public List<Transaction> PrintTransaction(int accountNo) throws BankAccountException {
		return bankdao.printTransactions(accountNo);
	}
}
