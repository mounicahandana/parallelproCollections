package com.cpg.dao;

import java.util.List;

import com.cpg.bean.Customer;
import com.cpg.bean.Transaction;
import com.cpg.exception.BankAccountException;

public interface IBankDao {
	public int createBankAccount(Customer customerData, double amount) throws BankAccountException;
	public double showBalance(int accountNo) throws BankAccountException;
	List<Transaction> deposit(int accountNo, double amount) throws BankAccountException;
	List<Transaction> withdraw(int accountNo,double amount) throws BankAccountException;
	List<Transaction> fundTransfer(int sourceAccount,int destinationAccount,double amount) throws BankAccountException;
	List<Transaction> printTransactions(int accountNo) throws BankAccountException;
}
