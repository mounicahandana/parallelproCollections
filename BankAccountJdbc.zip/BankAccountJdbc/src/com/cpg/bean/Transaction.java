package com.cpg.bean;

import java.sql.Date;

public class Transaction {
	private int transactionNum;
	private String transactionType;
	private Date transactionDate;
	private int accountNo;
	private double amount;

	public int getTransactionNum() {
		return transactionNum;
	}

	public void setTransactionNum(int transactionNum) {
		this.transactionNum = transactionNum;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Transaction [transactionNum=" + transactionNum + ", transactionType=" + transactionType
				+ ", transactionDate=" + transactionDate + ", accountNo=" + accountNo + ", amount=" + amount + "]";
	}

	public Transaction(int transactionNum, String transactionType, Date transactionDate, int accountNo, double amount) {
		super();
		this.transactionNum = transactionNum;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.accountNo = accountNo;
		this.amount = amount;
	}

	public Transaction() {
		super();
	}

}
