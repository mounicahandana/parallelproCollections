package com.cpg.exception;

public class BankAccountException extends Exception {

	public BankAccountException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankAccountException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
