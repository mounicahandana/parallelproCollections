package com.cpg.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cpg.bean.BankBean;
import com.cpg.service.BankServiceImp;
import com.cpg.service.IBankService;

public class BankUi {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {

		Scanner sc = new Scanner(System.in);
		IBankService bser = new BankServiceImp();
		int i = 1001;

		while (true) {

			System.out.println("Wallet Creation");
			// System.out.println();
			System.out.println("  1. Create new Wallet Account");
			System.out.println("  2. Show current Balance: ");
			System.out.println("  3. Deposit Amount: ");
			System.out.println("  4. Withdraw Amount: ");
			System.out.println("  5. Transfer Amount: ");
			System.out.println("  6. Transaction: ");
			System.out.println("  7. Information: ");
			System.out.println("  8. Exit: ");

			System.out.print("Enter Your Choice : ");
			int choice = sc.nextInt();
			switch (choice) {

			case 1:
				System.out.print("Enter your name : ");
				String name = sc.next();
				name += sc.nextLine();
				while (!bser.checkName(name)) {

					System.out.print("Enter your name : ");
					name = sc.next();
					name += sc.nextLine();
				}

				System.out.print("Enter your mobile number : ");
				String mob = sc.next();
				while (!bser.checkMobile(mob)) {
					System.out.print("Enter your mobile number : ");
					mob = sc.next();
				}

				System.out.print("Enter a password :");
				String password = sc.next();
				while (!bser.checkPassword(password)) {
					System.out.print("Enter a password :");
					password = sc.next();
				}

				String st = bser.addAccount(name, mob, password, i);
				i++;
				System.out.print("    " + st);

				break;

			case 2:
				System.out.print("Enter Your Account number : ");
				long accNo = sc.nextLong();
				if (bser.checkAccNo(accNo)) {
					System.out.print("Enter your Password : ");
					String passW = sc.next();
					if (bser.checkPassword(passW, accNo)) {
						long balnce = bser.getBalance(accNo);
						System.out.print("Your account balance is : Rs." + balnce + "\n");
					}
				}
				break;

			case 3:
				System.out.print("Enter Your Account number : ");
				accNo = sc.nextLong();
				if (bser.checkAccNo(accNo)) {
					System.out.print("Enter your Password : ");
					String passW = sc.next();
					if (bser.checkPassword(passW, accNo)) {

						System.out.print("Enter the amount to be deposited : Rs.");
						long bal1 = sc.nextInt();
						long bal2 = bser.getBalance(accNo) + bal1;

						bser.setBalance(accNo, bal2, "\n    TransID : " + i + "       Amount credited  Rs." + bal1);
						i++;
						System.out.print("Amount You deposited is Rs." + bal1 + "\n");
						System.out.print("Total balance is Rs." + bser.getBalance(accNo) + "\n");

					}
				}
				break;

			case 4:
				System.out.print("Enter Your Account number : ");
				accNo = sc.nextLong();
				if (bser.checkAccNo(accNo)) {
					System.out.print("Enter your Password : ");
					String pass = sc.next();
					if (bser.checkPassword(pass, accNo)) {

						System.out.print("Enter the amount to be withdrawn : Rs.");
						long bal1 = sc.nextInt();
						long bal2 = bser.getBalance(accNo) - bal1;
						bser.setBalance(accNo, bal2, "\n    TransID : " + i + "       Amount debited    Rs." + bal1);
						System.out.print("    Amount You withdraw is Rs." + bal1 + "\n");
						System.out.print("    Total balance is Rs." + bser.getBalance(accNo) + "\n");
						i++;
					}
				}
				break;

			case 5:
				System.out.print("Enter Your Account number : ");
				accNo = sc.nextLong();
				if (bser.checkAccNo(accNo)) {
					System.out.print("Enter your Password : ");
					String pass = sc.next();
					if (bser.checkPassword(pass, accNo)) {
						System.out.print("Enter Account number where you want to transer fund : ");
						long accNo1 = sc.nextLong();
						if (bser.checkAccNo(accNo1)) {
							long bal = bser.getBalance(accNo);
							long bal1 = bser.getBalance(accNo1);

							System.out.print("Enter the amount to be transferred : Rs.");
							long trans = sc.nextInt();
							bser.setBalance(accNo, bal - trans, "\n    TransID : " + i + "       Amount debited    Rs."
									+ trans + "  to Account Number " + accNo1);
							bser.setBalance(accNo1, bal1 + trans, "\n    TransID : " + i
									+ "        Amount credited  Rs." + trans + "  from Account Number " + accNo);
							System.out.print("    Amount You transferred is Rs." + trans + "\n");
							System.out.println("    Total balance is Rs." + bser.getBalance(accNo) + "\n");
							i++;
						}
					}
				}
				break;

			case 6:
				System.out.print("Enter Your Account number : ");
				accNo = sc.nextLong();
				if (bser.checkAccNo(accNo)) {
					System.out.print("Enter your Password : ");
					String pass = sc.next();
					if (bser.checkPassword(pass, accNo)) {
						System.out.println("Mini Statment");
						String str = bser.getTransaction(accNo);
						System.out.print("    " + str + "\n");
						System.out.print("Total balance is Rs." + bser.getBalance(accNo) + "\n");

					}
				}
				break;
			case 7:
				System.out.print("Enter Your Account number : ");
				accNo = sc.nextLong();
				if (bser.checkAccNo(accNo)) {
					System.out.print("Enter your Password : ");
					String pass = sc.next();
					if (bser.checkPassword(pass, accNo)) {
						BankBean b = bser.getInfo(accNo);
						System.out.println("Account Information \n   Account Holder Name : " + b.getName()
								+ "           *\n*    Account Number      : " + b.getAccNo()
								+ "    *\n*    Mobile Number       : " + b.getMobile()
								+ "    *\n*    Account Balance     : Rs." + b.getBalance() + "       *");
						System.out.println(" \n");
					}
				}
				break;

			case 8:
				System.exit(0);
			default:
				System.out.println("Enter proper choice : ");
				break;

			}

		}

	}
}