package com.cpg.service;

import java.sql.SQLException;


import com.cpg.bean.BankBean;
import com.cpg.dao.BankDaoImp;
import com.cpg.dao.IBankDao;



public class BankServiceImp implements IBankService {
	IBankDao bdao=new BankDaoImp();

	class MyException extends Exception {
		String s1;

		MyException(String s) {
			s1 = s;

		}

		public String toString() {
			return (s1);
		}

	}
	
	public boolean checkName(String name) {
		// TODO Auto-generated method stub

		String regex = "^[A-Z][a-z]*( [A-Z][a-z]*)*";
		try {
		if(name.matches(regex)) 
		return true;
		else 
			throw new MyException("Invalid Name");}
		catch (MyException E) {
			System.out.println(E);
			return false;
			}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	 //Validating Name of new account Holder
	/*public boolean checkName(String name) {
		int n = name.length();
		char[] ch = name.toCharArray();
		for (int i = 0; i < n; i++) {
			try {
				if (ch[i] > 64 && ch[i] < 122 && ch[0]>64 && ch[0]<90) {
					continue;
				} else {
					throw new MyException("Invalid Name");
				}
			} catch (MyException E) {
				System.out.println(E);
				return false;
			}

		}
		return true;

	}*/
	
	public boolean checkMobile(String mobileno) {
		// TODO Auto-generated method stub
		int n = mobileno.length();
		char []ch=mobileno.toCharArray();
		
		try {
			if (n == 10 ) {
				for(int i=0;i<n;i++) {
					if(ch[i]>47 && ch[i]<58) {
						continue;
					}
					else
						throw new MyException("    Invalid Number \n    Enter 10 digits");
											
				}
				return true;
				
			} else {
				throw new MyException("    Invalid Number \n    Enter 10 digits");
			}
		} catch (MyException E) {
			System.out.println(E);
			return false;
		}

	}
	
	
	public boolean checkPassword(String password) {
		// TODO Auto-generated method stub
		try {
			if (password.length() >= 6) {
				return true;
			} else {
				throw new MyException("    Invalid Password \n    Enter more than six characters");
			}
		} catch (MyException E) {
			System.out.println(E);
			return false;
		}
	}

	public String addAccount(String name, String mobile, String password, int i)
			throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		long accNo = Long.parseLong(mobile) - 10000;
		if (bdao.checkMobile(mobile)) {
			BankBean bb = new BankBean(name, accNo, mobile, password, 1000, "    Account Created Successfully \n    TransID : "+i+"       Amount Deposited Rs.1000");
			bdao.setData(bb);
			return "Account Created Successfully \n    Your Account number is \"" + accNo +"\"\n";
		} else
			return "Account already created ";
	}

	public boolean checkPassword(String str, long accno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		try {
			if (bdao.checkPassword(str, accno)) {

				return true;
			} else
				throw new MyException("Wrong Password");
		} catch (MyException E) {
			System.out.println(E);
		}
		return false;
	}
	
	public boolean checkAccNo(long accno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		try {
			if (bdao.checkAccNo(accno)) {

				return true;
			}

			else
				throw new MyException("Wrong Account Number");
		} catch (MyException E) {
			System.out.println(E);
		}
		return false;
	}

	public long getBalance(long accno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		long bal = bdao.getBalance(accno);
		return bal;
	}

	public void setBalance(long accno, long balance, String str) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		bdao.setBalance(accno, balance, str);
	}
	
	
	public String getTransaction(long accno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		String str = bdao.getTransaction(accno);
		return str;
	}
	
	public BankBean getInfo(long accno) {
		// TODO Auto-generated method stub
		BankBean b=bdao.getInfo(accno);
		return b;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
