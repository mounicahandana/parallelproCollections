package com.cpg.service;

import java.sql.SQLException;

import com.cpg.bean.BankBean;

public interface IBankService {

	boolean checkName(String name);

	boolean checkMobile(String mob);

	boolean checkPassword(String password);

	String addAccount(String name, String mob, String password, int i) throws SQLException, ClassNotFoundException;

	boolean checkPassword(String passW, long accNo) throws ClassNotFoundException, SQLException ;

	boolean checkAccNo(long accNo) throws ClassNotFoundException, SQLException;

	long getBalance(long accNo) throws ClassNotFoundException, SQLException;

	void setBalance(long accNo, long bal2, String string) throws ClassNotFoundException, SQLException;

	String getTransaction(long accNo)  throws ClassNotFoundException, SQLException;

	BankBean getInfo(long accNo);

	

}
