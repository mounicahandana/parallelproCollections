package com.cpg.dao;

import java.sql.SQLException;
import java.util.HashMap;

import com.cpg.bean.BankBean;





public class BankDaoImp implements IBankDao
{
	HashMap hm = new HashMap();	  
	BankBean bb1;                 
	

	public boolean checkMobile(String mobileno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		if (hm.containsKey(mobileno + 10000))
			return false;
		else
			return true;

		
	}
	
	
	public void setData(BankBean bb) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		hm.put(bb.getAccNo(), bb);
	}
	
	public boolean checkPassword(String str, long accno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		if (hm.containsKey(accno)) {
			bb1 = (BankBean) hm.get(accno);
			if (str.equals(bb1.getPassword())) {
				return true;
			}
			return false;
		} else
			return false;
	}
	
	
	

	public boolean checkAccNo(long accno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		if (hm.containsKey(accno))
			return true;
		else
			return false;
	}


	@Override
	public long getBalance(long accno) {
		// TODO Auto-generated method stub
		if (hm.containsKey(accno)) {
			bb1 = (BankBean) hm.get(accno);
			return bb1.getBalance();
		} else
			return 9999;
	}


	@Override
	public void setBalance(long accno, long balance, String str) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		if (hm.containsKey(accno)) {
			bb1 = (BankBean) hm.get(accno);
			bb1.setBalance(balance);
			String str1 = bb1.getTran() + str;
			bb1.setTran(str1);

		}
		
	}


	@Override
	public String getTransaction(long accno) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		if (hm.containsKey(accno)) {
			bb1 = (BankBean) hm.get(accno);
			return bb1.getTran();
		} else
			return " ";
	}


	@Override
	public BankBean getInfo(long accno) {
		// TODO Auto-generated method stub
		BankBean b=(BankBean)hm.get(accno);
		return b;
	}

	
	
	
	
	
	
	
	
	
}
