package com.cpg.dao;

import java.sql.SQLException;

import com.cpg.bean.BankBean;

public interface IBankDao {

	boolean checkMobile(String mobile) throws ClassNotFoundException, SQLException;

	void setData(BankBean bb) throws ClassNotFoundException, SQLException;

	boolean checkPassword(String str, long accno) throws ClassNotFoundException, SQLException;

	boolean checkAccNo(long accno) throws ClassNotFoundException, SQLException;

	long getBalance(long accno);

	void setBalance(long accno, long balance, String str)  throws ClassNotFoundException, SQLException;

	String getTransaction(long accno) throws ClassNotFoundException, SQLException;

	BankBean getInfo(long accno);

}
