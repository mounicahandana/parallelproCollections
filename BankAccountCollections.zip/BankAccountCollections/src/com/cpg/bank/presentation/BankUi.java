package com.cpg.bank.presentation;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cpg.bank.bean.Customer;
import com.cpg.bank.bean.Transaction;
import com.cpg.bank.exceptions.BankException;
import com.cpg.bank.service.BankService;
import com.cpg.bank.service.IBankService;

public class BankUi {

	
	@SuppressWarnings("resource")
	public static void main(String[] args)  throws BankException{
		IBankService service = new BankService();
		Scanner scanner = null;
		String choice;
		boolean Value = false;
		do {
			System.out.println("*** welcome to Capgemini Bank***");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transactions");
			System.out.println("7.Exit");
			
			int ch = 0;
			boolean choiceFlag = false;
			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter input:");
				try {
					ch = scanner.nextInt();
					choiceFlag = true;
					boolean nameFlag = false;
					String name = "";
					switch (ch) {

					case 1:
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Customer name:");
							name = scanner.nextLine();
							try {
								/* service.isNameValid(name); */
								service.isNameValid(name);
								nameFlag = true;
							} catch (BankException e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!nameFlag);

						System.out.println("Enter customer email: ");
						String email = scanner.nextLine();

						String address = "";
						boolean addressFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Customer address:");
							try {
								address = scanner.nextLine();
								service.isAddressValid(address);
								addressFlag = true;
							} catch (BankException e) {
								addressFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!addressFlag);

						String mobile = "";
						boolean mobileFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Customer Mobile:");
							try {
								address = scanner.nextLine();
								service.isMobileValid(mobile);
								mobileFlag = true;
							} catch (BankException e) {
								mobileFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!mobileFlag);

						Customer customer = new Customer(0, name, email, mobile, address, 0);
					
						try {
							int accountNo = service.createAccount(customer);
							System.out.println("Customer account created successfully with account number: " + accountNo);
						} catch (BankException e) {
							System.err.println(e.getMessage());
						}
						break;
					case 2: {
						System.out.println("Enter your account number: ");
						int accountNo = scanner.nextInt();
						try {
							double balance = service.showBalance(accountNo);
							System.out.println("balance for the account no is: " + balance);
						} catch (BankException e) {
							e.printStackTrace();
						}
					}
						break;

					case 3: {
						System.out.println("Enter your account number: ");
						int accountNo = scanner.nextInt();
						System.out.println("Enter the amount you want to deposit: ");
						double depositAmount = scanner.nextDouble();
						try {
							List<Transaction> transactionList = service.deposit(accountNo, depositAmount);
							System.out.println(transactionList);
						} catch (BankException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
						break;

					case 4: {
						System.out.println("Enter your account number: ");
						int accountNo = scanner.nextInt();
						System.out.println("Enter the amount you want to withdraw: ");
						double withdrawAmount = scanner.nextDouble();
						try {
							List<Transaction> transactionList = service.withdraw(accountNo, withdrawAmount);
							System.out.println(transactionList);
						} catch (BankException e) {
							e.printStackTrace();
						}
					}
						break;

					case 5: {
						System.out.println("Enter your account number: ");
						int sourceAccountNo = scanner.nextInt();
						System.out.println("Enter destination account number: ");
						int destinationAccountNo = scanner.nextInt();
						System.out.println("Enter the amount you want to withdraw: ");
						double transferAmount = scanner.nextDouble();
						try {
							List<Transaction> transactionList = service.fundTransfer(sourceAccountNo,
									destinationAccountNo, transferAmount);
							System.out.println(transactionList);
						} catch (BankException e) {
							e.printStackTrace();
						}
					}
						break;

					case 6: {
						System.out.println("Enter your account number: ");
						int accountNo = scanner.nextInt();
						try {
							List<Transaction> transactionList = service.printTransactions(accountNo);
							System.out.println(transactionList);
						} catch (BankException e) {
							e.printStackTrace();
						}
					}
						break;

					case 7:
						System.out.println("Thank you, visit Again");
						System.exit(0);
						break;
					default:
						System.out.println("input should be 1 or 2 or 3");
						choiceFlag = false;
						break;
					}
				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("Input should contain only digits");
				}
			} while (!choiceFlag);
			do {
				scanner = new Scanner(System.in);
				System.out.println("Do you want to continue again [yes/no]");
				choice = scanner.nextLine();
				if (choice.equalsIgnoreCase("yes")) {
					Value = true;
					break;
				} else if (choice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					Value = false;
					break;
				} else {
					System.out.println("enter yes or no");
					Value = false;
					continue;
				}
			} while (!Value);
		} while (Value);
		scanner.close();
	}
}
