package com.cpg.bank.bean;

public class Customer {

	private int accountNum;
	private String name;
	private String emailId;
	private String mobile;
	private String address;
	private double balance;
	public Customer() {
		super();
	}
	public int getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(int accountNum) {
		this.accountNum = accountNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Customer [accountNum=" + accountNum + ", name=" + name + ", emailId=" + emailId + ", mobile=" + mobile
				+ ", address=" + address + ", balance=" + balance + "]";
	}
	public Customer(int accountNum, String name, String emailId, String mobile, String address, double balance) {
		super();
		this.accountNum = accountNum;
		this.name = name;
		this.emailId = emailId;
		this.mobile = mobile;
		this.address = address;
		this.balance = balance;
	}
	
	
}
