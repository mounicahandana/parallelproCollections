package com.cpg.bank.bean;

public class Transaction {
	private int accountNum;
	private int transactionId;
	private String transactionType;
	private String transactionDate;
	private double amount;
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(int accountNum) {
		this.accountNum = accountNum;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Transaction(int accountNum, int transactionId, String transactionType, String transactionDate,
			double amount) {
		super();
		this.accountNum = accountNum;
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.amount = amount;
	}
	
	
}
