package com.cpg.bank.utility;

import java.util.HashMap;
import java.util.Map;

import com.cpg.bank.bean.Customer;


public class AccountRepository {
	private static Map<Integer, Customer> customer = new HashMap<>();
	static {
		customer.put(145, new Customer(123,"Mickey","mickey1309@gmail.com","7793948566","Hyderabad",50000));
		customer.put(256, new Customer(256,"Honey","honey1309@gmail.com","8074355984","Bangalore",100000));
		customer.put(321, new Customer(321,"Sagarika","sagarika@gmail.com","8185958977","Chennai",55555));
		customer.put(973, new Customer(973,"Kanikella","kanikella@gmail.com","8500505897","Rajahmundry",80000));
	}
	public static Map<Integer, Customer> getCustomers() {
		return customer;
	}

	public static void setVehicles(Map<Integer, Customer> customers) {
		AccountRepository.customer = customers;
	}

}
