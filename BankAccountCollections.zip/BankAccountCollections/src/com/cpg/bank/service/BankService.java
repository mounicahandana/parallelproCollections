package com.cpg.bank.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cpg.bank.bean.Customer;
import com.cpg.bank.bean.Transaction;
import com.cpg.bank.dao.BankDao;
import com.cpg.bank.exceptions.BankException;

public class BankService implements IBankService {
	BankDao dao = new BankDao();

	@Override
	public int createAccount(Customer customer) throws BankException {
		return dao.createAccount(customer);
	}

	@Override
	public double showBalance(int accountno) throws BankException {
		return dao.showBalance(accountno);
	}

	@Override
	public List<Transaction> deposit(int accountno, double amount) throws BankException {
		return dao.deposit(accountno, amount);
	}

	@Override
	public List<Transaction> withdraw(int accountno, double amount) throws BankException {
		return dao.withdraw(accountno, amount);
	}

	@Override
	public List<Transaction> fundTransfer(int sourceAccountno, int destinationAccountNo, double amount)
			throws BankException {
		return dao.fundTransfer(sourceAccountno, destinationAccountNo, amount);
	}

	@Override
	public List<Transaction> printTransactions(int accountno) throws BankException {
		return dao.printTransactions(accountno);
	}

	@Override
	public boolean isNameValid(String name) throws BankException {
		boolean resultFlag = false;
		String RegEx = "[A-Z]{1}[a-z]{4,}";

		if (!Pattern.matches(RegEx, name)) {
			throw new BankException("first letter should be capital and length should be greater than 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

	@Override
	public boolean isMailValid(String mail) throws BankException {
		Pattern mobPattern = Pattern.compile("[A-Za-z][@gmail.com]");
		Matcher matcher = mobPattern.matcher(mail);
		if (matcher.matches())
			throw new BankException("Invalid mail ID");
		else
			return false;
	}

	@Override
	public boolean isMobileValid(String mobile) throws BankException {
		String input1 = String.valueOf(mobile);
		Pattern mobPattern = Pattern.compile("[7,8,9]{1}[0-9]{9}");
		Matcher matcher = mobPattern.matcher(input1);
		if (matcher.matches())
			return true;
		else
			return false;
	}

	@Override
	public boolean isAddressValid(String address) throws BankException {
		boolean resultFlag = false;
		String RegEx = "[A-Z]{1}[a-z]{4,}";

		if (!Pattern.matches(RegEx, address)) {
			throw new BankException("first letter should be capital and length should be greater than 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

}
