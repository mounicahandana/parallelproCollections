package com.cpg.bank.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cpg.bank.bean.Customer;
import com.cpg.bank.bean.Transaction;


public interface IBankDao {
	static List<Transaction> printTransaction = new ArrayList<>();
	Map<Integer, Customer> customerList = new HashMap<>();
	public int createAccount(Customer customer);
	public double showBalance(int accountno);
	List<Transaction> deposit(int accountno, double amount);
	List<Transaction> withdraw(int accountno, double amount);
	List<Transaction> fundTransfer(int sourceAccountNo,int destinationAccountNo,double amount);
	List<Transaction> printTransactions(int accountno);
}
