package com.capgemini.bank.service;

import java.util.List;
import com.capgemini.bank.bean.CustomerDetails;
import com.capgemini.bank.bean.TransactionDetails;
import com.capgemini.bank.exception.BankAccountException;


public interface BankAccountService {
	public int createAccount(CustomerDetails customerData,double amount) throws BankAccountException;
	public double showBalance(int accountNo) throws BankAccountException;
	List<TransactionDetails> deposit(int accountNo,double amount) throws BankAccountException;
	List<TransactionDetails> withdraw(int accountNo,double amount) throws BankAccountException;
	List<TransactionDetails> fundTransfer(int sourceAccount,int destinationAccount,double amount) throws BankAccountException;
	List<TransactionDetails> PrintTransaction(int accountNo) throws BankAccountException;
	public boolean isNameValid(String name) throws BankAccountException;
	public boolean isAddressValid(String address) throws BankAccountException;
	public boolean isMobileValid(String mobile) throws BankAccountException;
	public boolean isAmountValid(double amount) throws BankAccountException;
}
