package com.capgemini.bank.exception;

public class BankAccountException extends Exception{

	public BankAccountException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BankAccountException(String message) {
		super(message);
	}
}
